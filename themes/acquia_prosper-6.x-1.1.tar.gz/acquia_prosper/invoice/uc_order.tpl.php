<?php
// $Id: uc_order.tpl.php 7867 2010-08-25 20:54:46Z jeremy $

/**
 * @file
 * This file is a dummy template.
 *
 * It serves as a reminder to theme authors that they must have a
 * uc_order.tpl.php file in their theme if they want to override the other
 * order templates.
 */
